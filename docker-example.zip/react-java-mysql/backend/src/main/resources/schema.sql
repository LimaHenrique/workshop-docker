CREATE TABLE IF NOT EXISTS example.greetings (
    id INTEGER AUTO_INCREMENT,
    name varchar(50) NOT NULL,
    PRIMARY KEY (id)
);
